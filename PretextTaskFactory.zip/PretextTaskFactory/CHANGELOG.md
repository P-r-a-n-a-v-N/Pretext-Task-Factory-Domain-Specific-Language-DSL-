# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2025-01-01

### Added
- Core DSL with `PretextTask` ADT (Rotate, Permute, TimeWarp, Identity, Seq, Par)
- Smart constructors with validation for all task types
- Semigroup/Monoid instances for sequential composition
- Interpreter for images and temporal sequences
- Static and dynamic verification engine
- Algebraic optimizer with 7 rewrite rules
- Random task generator (dependency-free LCG)
- Multiple pretty-printing formats (infix, tree, JSON, execution log)
- Comprehensive test suite (60+ test cases, no external dependencies)
- Full README documentation
